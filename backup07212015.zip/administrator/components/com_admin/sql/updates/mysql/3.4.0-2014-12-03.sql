UPDATE `#__extensions` SET `protected` = '0' WHERE `name` = 'plg_editors-xtd_article' AND `type` = "plugin" AND `element` = "article" AND `folder` = "editors-xtd";
